<?php 
 header("Location: questionario.html" ) ;
?>