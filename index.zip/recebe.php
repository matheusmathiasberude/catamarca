<?php
// require_once('verificas.php');
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $q1 = $_POST['q1'] ?? '';
  $q2 = $_POST['q2'] ?? '';
  $q3 = $_POST['q3'] ?? '';
  $q4 = $_POST['q4'] ?? '';
  $q5 = $_POST['q5'] ?? '';
  $q6 = $_POST['q6'] ?? '';
  $q7 = $_POST['q7'] ?? '';
  $q8 = $_POST['q8'] ?? '';
  $q9 = $_POST['q9'] ?? '';
  $q10 = $_POST['q10'] ?? '';
  $q11 = $_POST['q11'] ?? '';
  $q12 = $_POST['q12'] ?? '';
  $q13 = $_POST['q13'] ?? '';
  $q14 = $_POST['q14'] ?? '';
  $q15 = $_POST['q15'] ?? '';
  $q16 = $_POST['q16'] ?? '';
  $q17 = $_POST['q17'] ?? '';
} 
$dbFile = 'trabalho.db';
if (file_exists($dbFile)) {
  $db = new SQLite3($dbFile);
  $query = "CREATE TABLE IF NOT EXISTS questoes(id INTEGER PRIMARY KEY AUTOINCREMENT,q1 INTEGER,q2 INTEGER,q3 INTEGER,q4 INTEGER,q5 INTEGER,q6 INTEGER,q7 INTEGER,q8 INTEGER,q9 INTEGER,q10 INTEGER,q11 INTEGER,q12 INTEGER,q13 INTEGER,q14 INTEGER,q15 INTEGER,q16 INTEGER,
q17 INTEGER)";
  $db->exec($query);
  $db->close();
}
  $db = new SQLite3($dbFile);
  $stmt = $db->prepare(
    "INSERT INTO questoes(q1,q2,q3,q4,q5,q6,q7,q8,q9,q10,q11,q12, q13,q14,q15,q16,q17)VALUES (:q1,:q2,:q3,:q4,:q5,:q6, :q7,:q8,:q9, :q10,:q11,:q12, :q13,:q14,:q15,:q16,:q17)");
  $stmt->bindValue(':q1', $q1);
  $stmt->bindValue(':q2', $q2);
  $stmt->bindValue(':q3', $q3);
  $stmt->bindValue(':q4', $q4);
  $stmt->bindValue(':q5', $q5);
  $stmt->bindValue(':q6', $q6);
  $stmt->bindValue(':q7', $q7);
  $stmt->bindValue(':q8', $q8);
  $stmt->bindValue(':q9', $q9);
  $stmt->bindValue(':q10', $q10);
  $stmt->bindValue(':q11', $q11);
  $stmt->bindValue(':q12', $q12);
  $stmt->bindValue(':q13', $q13);
  $stmt->bindValue(':q14', $q14);
  $stmt->bindValue(':q15', $q15);
  $stmt->bindValue(':q16', $q16);
  $stmt->bindValue(':q17', $q17);
  $stmt->execute();
  $db->close();

Echo "Respostas enviadas com sucesso!";
?>
<a href="consultaform.php">Consultar</a>"

