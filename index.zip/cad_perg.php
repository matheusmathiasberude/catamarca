<?php
// require_once('verificas.php');
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $Nr_P = $_POST['Nr_P'] ?? '';
  $pergunta = $_POST['pergunta'] ?? '';
}

$dbFile = 'trabalho.db';
if (file_exists($dbFile)) {
  $db = new SQLite3($dbFile);
  $query = "CREATE TABLE IF NOT EXISTS perguntas(id INTEGER PRIMARY KEY AUTOINCREMENT,pergunta TEXT)";
  $db->exec($query);
  $db->close();
}
  $db = new SQLite3($dbFile);
  $stmt = $db->prepare("UPDATE perguntas
     SET pergunta = :pergunta WHERE id = :Nr_P");
  // $stmt = $db->prepare("INSERT INTO perguntas (pergunta) VALUES (:pergunta)");
  $stmt->bindValue(':Nr_P', $Nr_P);
  $stmt->bindValue(':pergunta', $pergunta);
  $stmt->execute();
  $db->close();

Echo "A sua resposta forá enviadas com sucesso!";
?>
<a href="consulta_p.php">Consultar</a>"