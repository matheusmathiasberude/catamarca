<?php
$dbFile = 'trabalho.db';
if (file_exists($dbFile)) {
    $db = new SQLite3($dbFile);
    $query = $db->query("SELECT * FROM perguntas");
    if ($query) {
    echo "<Html><HEAD>
            <link rel='stylesheet' type='text/css' href='styles.css' media='screen'/></HEAD>
        <body> <center><br>";
        echo "<h2 class='md'>QUESTIONÁRIO DE OPINIÃO</h2>
        <form action='recebe.php' method='POST'>";
        echo "<table border='20' class='box-model2'>
<tr> 
    <th width= '570'>PERGUNTAS</th>
    <th width= '100'>ÓTIMO</th>
    <th width= '100'>BOM</th>
    <th width= '100'>RUIM</th>
    <th width= '100'>PÉSSIMO</th>
</tr>";
while ($row = $query->fetchArray(SQLITE3_ASSOC)) {
  echo "<tr>";
  echo "<th align='left'>". $row['id'].") ". $row['pergunta']."</th>";
  echo "<th><input type='radio' name= 'q".$row['id']. "' value='5'></th>";
  echo "<th><input type='radio' name= 'q".$row['id']. "' value='4'></th>";
  echo "<th><input type='radio' name= 'q".$row['id']. "' value='2'></th>";
  echo "<th><input type='radio' name= 'q".$row['id']. "' value='1'></th>";
  echo "</tr>"; 
}  
echo " </table>
<input type='submit'>
</form>
</body>
</html>";
}}
?>