<?php
//require_once('verificas.php');
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $usr = $_POST['usr'] ?? '';
  $pass = $_POST['pass'] ?? '';
  $nome = $_POST['nome'] ?? '';
}
$dbFile = 'trabalho.db';
if (!file_exists($dbFile)) {
    $db = new SQLite3($dbFile);
    $query = "CREATE TABLE IF NOT EXISTS usuarios (
        id INTEGER PRIMARY KEY AUTOINCREMENT,
        usr TEXT NOT NULL,
        pass TEXT NOT NULL,
        nome TEXT NOT NULL
    )";
    $db->exec($query);
    $db->close();
} else {
    $db = new SQLite3($dbFile);
    if (!empty($usr) && !empty($pass) && !empty($nome)) {
        $query = $db->prepare("INSERT INTO usuarios (usr, pass, nome) VALUES (:usr, :pass, :nome)");
        $query->bindValue(':usr', $usr);
        $query->bindValue(':pass', $pass);
        $query->bindValue(':nome', $nome);
        $query->execute();

        header("Location: login.html" ) ;
    } else {

        echo "Por favor, preencha todos os campos!";
    }
$db->close();
  }
  ?>
