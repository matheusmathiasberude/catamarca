<?php
//require_once('verificas.php');
session_start();
$dbFile = 'trabalho.db';
if (isset($_SESSION['usuario'])) {
    $usr = $_SESSION['usuario'];
    $db = new SQLite3($dbFile);
    $query = $db->prepare("DELETE FROM usuarios WHERE usr = :usr");
    $query->bindValue(':usr', $usr);
    $result = $query->execute();
    if ($result) {
      header("Location: login.html"); 
    } else {
        echo "Falha ao remover o registro.";
    }
    $db->close();
} else {
    echo "ID do registro não especificado.";
}
?>
