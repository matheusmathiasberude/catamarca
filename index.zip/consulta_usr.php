<?php
//require_once('verificas.php');
$dbFile = 'trabalho.db';
if (file_exists($dbFile)) {
    $db = new SQLite3($dbFile);
    $query = $db->query("SELECT * FROM usuarios");
    if ($query) {
    echo "<Html><HEAD>
            <link rel='stylesheet' type='text/css' href='styles.css' media='screen'/></HEAD>
        <body> <center><br>";
        echo "<h2 class='md'>Dados da Tabela 'usuarios'</h2>";
        echo "<table border='1' class='box-model2'>
                <tr> 
                    <th>ID</th>
                    <th>Senha</th>
                    <th>Usuário</th>
                    <th>Nome</th>
                    <th>Remover</th>
                </tr>";

        // Loop para exibir cada linha da tabela
        while ($row = $query->fetchArray(SQLITE3_ASSOC)) {

            echo "<tr>";
            echo "<td>" . $row['id'] . "</td>";
            echo "<td>" . $row['pass'] . "</td>";
            echo "<td>" . $row['usr'] . "</td>";
            echo "<td>" . $row['nome'] . "</td>";
            echo "<td>" . "<a href=remover.php?id=".$row['id']. ">Remover </a> </td>";
            echo "</tr>";
        }

        echo "</table>";
    } else {
        echo "Não foi possível buscar os dados.";
    }

    $db->close();
} else {
    echo "Banco de dados não encontrado.";
}
?>
<Html><HEAD>
    <link rel="stylesheet" type="text/css" href="styles.css" media="screen"/>
</HEAD>
<body> 
<br>

  </body>
  </html>