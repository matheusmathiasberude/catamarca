<?php
//require_once('verificas.php');
$dbFile = 'trabalho.db';
if (isset($_GET['id'])) {
    $id = $_GET['id'];
    $db = new SQLite3($dbFile);
    $query = $db->prepare("DELETE FROM questoes WHERE id = :id");
    $query->bindValue(':id', $id);
    $result = $query->execute();
    if ($result) {
      header("Location: consultaform.php"); 
    } else {
        echo "Falha ao remover o registro.";
    }
    $db->close();
} else {
    echo "ID do registro não especificado.";
}
?>
