<?php
session_start();
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
  $usr = $_POST['usr'] ?? '';
  $pass = $_POST['pass'] ?? '';
  if (!empty($usr) && !empty($pass)){
    $dbFile = 'trabalho.db';
    if (file_exists($dbFile)) {
      $db = new SQLite3($dbFile);
      $query = $db->prepare("SELECT * FROM usuarios WHERE usr = :usr");
      $query->bindValue(':usr', $usr);
      $result = $query->execute();

      if ($result) {
        $userData = $result->fetchArray(SQLITE3_ASSOC);
        if ($userData) {
          $_SESSION['usuario'] = $usr;
          if ($usr == 'aos')
          {
            header("Location: consultaform.php"); 
            exit;
          } else {
          header("Location: questionario2.php"); 
          exit();
        } 
        } else {
          header("Location: logout.php");
        }
      } else {
        echo "Erro de consulta ao banco de dados. <br>";
      }
      $db->close();
    } else {
      echo "Banco de dados não encontrado.<br>";
    }
  }
}
?>