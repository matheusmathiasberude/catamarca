<?php
//require_once('verificas.php');
$dbFile = 'trabalho.db';
if (file_exists($dbFile)) {
    $db = new SQLite3($dbFile);
    $query = $db->query("SELECT * FROM questoes");
    if ($query) {
    echo '<HTML>';
    echo '<HEAD>';
    echo "<link rel='stylesheet' type='text/css' href='styles.css' media='screen'/>
      </HEAD>
      <body>
      <center><br>
    <h2 class='md'>Dados da Tabela formularios</h2>
    <table border='1' class='box-model1'>
                <tr> 
                    <th> ID</th>
                    <th>Q 1</th>
                    <th>Q 2</th>
                    <th>Q 3</th>
                    <th>Q 4</th>
                    <th>Q 5</th>
                    <th>Q 6</th>
                    <th>Q 7</th>
                    <th>Q 8</th>
                    <th>Q 9</th>
                    <th>Q10</th>
                    <th>Q11</th>
                    <th>Q12</th>
                    <th>Q13</th>
                    <th>Q14</th>
                    <th>Q15</th>
                    <th>Q16</th>
                    <th>Q17</th>
                    <th>Remover</th>
                </tr>";

      while ($row = $query->fetchArray(SQLITE3_ASSOC)) {

        echo "<tr>";
        echo "<td align='center'> " . $row['id'] . "</td> ";

        echo "<td align='center'>" . $row['q1'] . "</td>";
        if($row['q1'] >3){$Bq1++;}else{$Mq1++;}

        echo "<td align='center'>" . $row['q2'] . "</td>";
        if($row['q2'] >3){$Bq2++;}else{$Mq2++;}
        echo "<td align='center'>" . $row['q3'] . "</td>";
        if($row['q3'] >3){$Bq3++;}else{$Mq3++;}
        echo "<td align='center'>" . $row['q4'] . "</td>";
        if($row['q4'] >3){$Bq4++;}else{$Mq4++;}
        echo "<td align='center'>" . $row['q5'] . "</td>";
        if($row['q5'] >3){$Bq5++;}else{$Mq5++;}
        echo "<td align='center'>" . $row['q6'] . "</td>";
        if($row['q6'] >3){$Bq6++;}else{$Mq6++;}
        echo "<td align='center'>" . $row['q7'] . "</td>";
        if($row['q7'] >3){$Bq7++;}else{$Mq7++;}
        echo "<td align='center'>" . $row['q8'] . "</td>";
        if($row['q8'] >3){$Bq8++;}else{$Mq8++;}
        echo "<td align='center'>" . $row['q9'] . "</td>";
        if($row['q9'] >3){$Bq9++;}else{$Mq9++;}
        echo "<td align='center'>" . $row['q10'] . "</td>";
        if($row['q10'] >3){$Bq10++;}else{$Mq10++;}
        echo "<td align='center'>" . $row['q11'] . "</td>";
        if($row['q11'] >3){$Bq11++;}else{$Mq11++;}
        echo "<td align='center'>" . $row['q12'] . "</td>";
        if($row['q12'] >3){$Bq12++;}else{$Mq12++;}
        echo "<td align='center'>" . $row['q13'] . "</td>";
        if($row['q13'] >3){$Bq13++;}else{$Mq13++;}
        echo "<td align='center'>" . $row['q14'] . "</td>";
        if($row['q14'] >3){$Bq14++;}else{$Mq14++;}
        echo "<td align='center'>" . $row['q15'] . "</td>";
        if($row['q15'] >3){$Bq15++;}else{$Mq15++;}
        echo "<td align='center'>" . $row['q16'] . "</td>";
        if($row['q16'] >3){$Bq16++;}else{$Mq16++;}
        echo "<td align='center'>" . $row['q17'] . "</td>";
        if($row['q17'] >3){$Bq17++;}else{$Mq17++;}
        echo "<td align='center'>" . "<a href=remover.php?id=".$row['id']. ">Remover </a></td>";
            echo "</tr>";
      } $t = $Bq1+$Mq1;
        echo "<tr>";
        echo "<td align='center'> Bom</td> ";
        echo "<td align='center'>" . substr($Bq1*100/$t,0,5) . "</td>";
        echo "<td align='center'>" . substr($Bq2*100/$t,0,5) . "</td>";
        echo "<td align='center'>" . substr($Bq3*100/$t,0,5) . "</td>";
        echo "<td align='center'>" . substr($Bq4*100/$t,0,5) . "</td>";
        echo "<td align='center'>" . substr($Bq5*100/$t,0,5) . "</td>";
        echo "<td align='center'>" . substr($Bq6*100/$t,0,5) . "</td>";
        echo "<td align='center'>" . substr($Bq7*100/$t,0,5) . "</td>";
        echo "<td align='center'>" . substr($Bq8*100/$t,0,5) . "</td>";
        echo "<td align='center'>" . substr($Bq9*100/$t,0,5) . "</td>";
        echo "<td align='center'>" . substr($Bq10*100/$t,0,5) . "</td>";
        echo "<td align='center'>" . substr($Bq11*100/$t,0,5) . "</td>";
        echo "<td align='center'>" . substr($Bq12*100/$t,0,5) . "</td>";
        echo "<td align='center'>" . substr($Bq13*100/$t,0,5) . "</td>";
        echo "<td align='center'>" . substr($Bq14*100/$t,0,5) . "</td>";
        echo "<td align='center'>" . substr($Bq15*100/$t,0,5) . "</td>";
        echo "<td align='center'>" . substr($Bq16*100/$t,0,5) . "</td>";
        echo "<td align='center'>" . substr($Bq17*100/$t,0,5) . "</td>";
        echo "<td align='center'> % </td>";
            echo "</tr>";
        echo "<tr>";
        echo "<td align='center'> Mal</td> ";
        echo "<td align='center'>" . substr($Mq1*100/$t,0,5) . "</td>";
        echo "<td align='center'>". substr($Mq2*100/$t, 0,5) . "</td>";
        echo "<td align='center'>" . substr($Mq3*100/$t,0,5) . "</td>";
        echo "<td align='center'>". substr($Mq4*100/$t,0,5) . "</td>";
        echo "<td align='center'>" . substr($Mq5*100/$t,0,5) . "</td>";
        echo "<td align='center'>" . substr($Mq6*100/$t,0,5) . "</td>";
        echo "<td align='center'>" . substr($Mq7*100/$t,0,5) . "</td>";
        echo "<td align='center'>" . substr($Mq8*100/$t,0,5) . "</td>";
        echo "<td align='center'>" . substr($Mq9*100/$t,0,5) . "</td>";
        echo "<td align='center'>" . substr($Mq10*100/$t,0,5) . "</td>";
        echo "<td align='center'>" . substr($Mq11*100/$t,0,5) . "</td>";
        echo "<td align='center'>" . substr($Mq12*100/$t,0,5) . "</td>";
        echo "<td align='center'>" . substr($Mq13*100/$t,0,5) . "</td>";
        echo "<td align='center'>" . substr($Mq14*100/$t,0,5) . "</td>";
        echo "<td align='center'>" . substr($Mq15*100/$t,0,5) . "</td>";
        echo "<td align='center'>" . substr($Mq16*100/$t,0,5) . "</td>";
        echo "<td align='center'>" . substr($Mq17*100/$t,0,5) . "</td>";
        echo "<td align='center'> % </td>";
            echo "</tr>";
        echo "</table>";
    } else {
        echo "Não foi possível buscar os dados.";
    }
    $db->close();
} else {
    echo "Banco de dados não encontrado.";
}
?>
<Html><HEAD>
    <link rel="stylesheet" type="text/css" href="styles.css" media="screen"/>
</HEAD>
<body> 
<center class="boton"><a href="questionario2.php">Responder novamente </a></center>


  </body>
  </html>